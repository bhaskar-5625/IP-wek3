// console.log is used to print anything in JavaScript it is same as print() in python
'use strict'
console.log("hello world");
console.log("harsha sai");
var firstName = "elon";

console.log(firstName)
var firstname = 'larry'
console.log(firstname)
var lastname = 'musk'
lastname = 'ellison'
console.log(lastname)

// let
let companies = 'spaceX, Tesla'
companies = 'spaceX, Tesla, Twitter'
console.log(companies)

// const
const pi = 3.14
console.log(pi)

console.log(firstName.length)
console.log(firstName[firstName.length-1]) // can get the index of a string even if we don't know about the length of that string
// string methods
// trim()
// this method is used to remove the unnecessary spaces in a string.
let name = '    Harsha    '
console.log(name.length)
let sameName = name.trim()
console.log(sameName.length)

